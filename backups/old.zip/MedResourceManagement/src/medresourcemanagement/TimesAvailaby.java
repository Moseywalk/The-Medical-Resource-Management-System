/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medresourcemanagement;

/**
 *
 * @author Gordo
 */
class TimesAvailaby {

    private String SundaySt;
    private String SundayEt;

    private String MondaySt;
    private String MondayEt;

    private String TuesdaySt;
    private String TuesdayEt;

    private String WednesdaySt;
    private String WednesdayEt;

    private String ThursdaySt;
    private String ThursdayEt;

    private String FridaySt;
    private String FridayEt;

    private String SaturdaySt;
    private String SaturdayEd;

    public void setSunTime() {

    }

    public void setMonTime() {

    }

    public void setTueTime() {

    }

    public void setWedTime() {

    }

    public void setThuTime() {

    }

    public void setFriTime() {

    }

    public void setSatTime() {

    }

}
