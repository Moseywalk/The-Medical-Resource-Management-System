/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import javax.swing.JFrame;

/**
 *
 * @author b00712596
 */
public class MyFrame extends JFrame{
    
    
    public static void run() 
    {

MainPanel a = new MainPanel();
a.setVisible(true);
a.setSize(500,200);
// a.setLocationRelativeTo(null);
       
        
               


    }
    
    
}