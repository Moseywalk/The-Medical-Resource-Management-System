/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medresourcemanagement;

//import gui.*;
//import gui.Login;
import gui.MyFrame;
import javax.swing.JFrame;

/**
 *
 * @author b00720507
 */
public class MedResourceManagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
//        JFrame fr1 = new JFrame();
//        Login log = new Login();
//        fr1.setContentPane(log);
//        fr1.setVisible(true);
//        fr1.setSize(400, 400);
//        fr1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//                
                
        
        
        
        
        MedResourceManagement mrm = new MedResourceManagement();
        mrm.setUpObjs();
        
        

    }

    public void setUpObjs() {
       
        MyFrame frame = new MyFrame();
    
        //example new surgeon 
//        Doctor s = new Surgery();
//        Doctor t = new Cardiology();
//        reg.addToRegister(s);
//        reg.addToRegister(t);
//        reg.deleteFromRegister("Gordon", reg.surgDocs);
      
    }
}
